#include <stdio.h>
#include <GL/glew.h>

void createPlane();
void drawPlane();

extern	unsigned int plane_vao;
