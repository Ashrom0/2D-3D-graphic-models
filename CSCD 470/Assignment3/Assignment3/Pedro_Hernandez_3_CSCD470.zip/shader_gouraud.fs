#version 430

in vec4 Color;
out vec4 fColor;

void main(void)
{
    fColor = Color;
}


