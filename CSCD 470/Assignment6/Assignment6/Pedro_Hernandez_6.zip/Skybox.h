#include <stdio.h>
#include <GL/glew.h>

void createSkybox();
void drawSkybox();

extern	unsigned int sky_vao;